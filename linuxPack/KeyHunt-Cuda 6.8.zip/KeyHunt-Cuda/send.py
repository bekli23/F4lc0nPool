# send.py — Sync client stats securely to MySQL database + multiple scanned ranges every random 10–35 seconds

import pymysql
import os
import hashlib
import base64
import time
import threading
import random
from config import CONFIG

API_FILE = "api.txt"
SYNC_FILE = "client_sync_summary.txt"
RANGE_LOG_FILE = "range_log.txt"
GPU_FILE = "gpu.txt"

# 🔐 Base64 encoded credentials
encoded_creds = {
    "DB_HOST": "ODQuNDYuMjQyLjE0OQ==",
    "DB_NAME": "cGFuZWw=",
    "DB_USER": "cGhwbXlhZG1pbg==",
    "DB_PASS": "V1c3KCY4cUBUNG=="
}

def decode_b64(key):
    return base64.b64decode(encoded_creds[key]).decode()

DB_HOST = decode_b64("DB_HOST")
DB_NAME = decode_b64("DB_NAME")
DB_USER = decode_b64("DB_USER")
DB_PASS = decode_b64("DB_PASS")

def compute_hash(lines):
    content = "\n".join(lines).encode("utf-8")
    return hashlib.sha256(content).hexdigest()

def get_user_id_by_api(api_key, cursor):
    cursor.execute("SELECT user_id FROM api_keys WHERE api_key = %s LIMIT 1", (api_key,))
    result = cursor.fetchone()
    return result[0] if result else None

def read_gpu_info():
    if not os.path.exists(GPU_FILE):
        return 0, ""
    with open(GPU_FILE, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f if line.strip()]
        gpu_lines = [line.replace("#", "GPU ") for line in lines if line.startswith("#")]
        return len(gpu_lines), "\n".join(gpu_lines)

def inject_gpu_info_into_sync_file():
    if not os.path.exists(SYNC_FILE):
        return
    with open(SYNC_FILE, "r", encoding="utf-8") as f:
        lines = f.read().splitlines()

    if any(line.startswith("GPU Info:") for line in lines):
        return

    gpu_count, gpu_info = read_gpu_info()
    lines = lines[:-1] if lines[-1].startswith("SIGNATURE:") else lines
    lines.append("GPU Info:")
    lines.extend(gpu_info.splitlines())
    lines.append(f"GPU Count: {gpu_count}")
    lines.append(f"SIGNATURE: {compute_hash(lines)}")

    with open(SYNC_FILE, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

def send_stats_to_mysql():
    if not os.path.exists(API_FILE) or not os.path.exists(SYNC_FILE):
        print("[WARNING] Missing api.txt or client_sync_summary.txt.")
        return

    try:
        inject_gpu_info_into_sync_file()

        with open(API_FILE, "r") as f:
            api_key = f.read().strip()

        with open(SYNC_FILE, "r", encoding="utf-8") as f:
            lines = f.read().splitlines()

        if not lines or not lines[-1].startswith("SIGNATURE:"):
            print("[SECURITY] Signature missing.")
            return

        content_lines = lines[:-1]
        signature = lines[-1].split("SIGNATURE:", 1)[1].strip()
        if compute_hash(content_lines) != signature:
            print("[SECURITY] Signature invalid. Aborting.")
            return

        total_points = 0
        puzzle_bits = None
        range_usage = {}
        gpu_speed = ""
        found_result = ""
        gpu_info_lines = []
        gpu_count = 0
        collecting_gpu_info = False

        for line in content_lines:
            if line.startswith("Scan Counter:"):
                total_points = int(line.split(":", 1)[1].strip())
            elif line.startswith("Puzzle:"):
                puzzle_bits = int(line.split(":", 1)[1].replace("bits", "").strip())
            elif line.startswith("Range Bits Usage:"):
                continue
            elif line.startswith("GPU Info:"):
                collecting_gpu_info = True
            elif line.startswith("GPU Count:"):
                try:
                    gpu_count = int(line.split(":", 1)[1].strip())
                    collecting_gpu_info = False
                except:
                    gpu_count = 0
            elif collecting_gpu_info:
                gpu_info_lines.append(line)
            elif line and line[0].isdigit() and ":" in line:
                try:
                    bit = int(line.split(":")[0].strip())
                    count = int(line.split(":")[1].split("-")[0].strip())
                    range_usage[bit] = count
                    if "[" in line:
                        gpu_speed = line.split("[")[-1].replace("]", "").strip()
                except:
                    continue
            elif line.startswith("Found Result Output:"):
                idx = content_lines.index(line)
                found_result = "\n".join(content_lines[idx+1:]).strip()
                break

        gpu_info = "\n".join(gpu_info_lines)

        connection = pymysql.connect(
            host=DB_HOST, user=DB_USER, password=DB_PASS, database=DB_NAME
        )
        cursor = connection.cursor()
        user_id = get_user_id_by_api(api_key, cursor)
        if not user_id:
            print("[ERROR] Invalid API key.")
            return

        range_usage_str = ", ".join([f"{k}:{v}" for k, v in sorted(range_usage.items())])

        cursor.execute("""
            INSERT INTO leaderboard (user_id, total_points, range_bits_usage, gpu_speed, puzzle_bits)
            VALUES (%s, %s, %s, %s, %s)
            ON DUPLICATE KEY UPDATE
                total_points = VALUES(total_points),
                range_bits_usage = VALUES(range_bits_usage),
                gpu_speed = VALUES(gpu_speed),
                puzzle_bits = VALUES(puzzle_bits),
                last_updated = CURRENT_TIMESTAMP
        """, (user_id, total_points, range_usage_str, gpu_speed, puzzle_bits))

        if found_result:
            cursor.execute("""
                INSERT INTO found_results_log (user_id, found_result)
                VALUES (%s, %s)
            """, (user_id, found_result))

        connection.commit()
        print(f"[SYNC]  Stats synced. User: {user_id}")

    except Exception as e:
        print(f"[ERROR] Failed to send stats to MySQL: {e}")
    finally:
        try:
            if connection:
                connection.close()
        except:
            pass

def send_scanned_ranges_loop():
    while True:
        try:
            if not os.path.exists(API_FILE) or not os.path.exists(RANGE_LOG_FILE):
                time.sleep(random.randint(60, 120))
                continue

            with open(API_FILE, "r") as f:
                api_key = f.read().strip()

            with open(RANGE_LOG_FILE, "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if ":" in line]

            if not lines:
                time.sleep(random.randint(60, 120))
                continue

            gpu_count, gpu_info = read_gpu_info()

            connection = pymysql.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASS, database=DB_NAME
            )
            cursor = connection.cursor()
            user_id = get_user_id_by_api(api_key, cursor)
            if not user_id:
                print("[ERROR] API key not found.")
                return

            for line in lines:
                try:
                    start, end = [x.strip() for x in line.split(":", 1)]
                    cursor.execute("""
                        SELECT 1 FROM scanned_ranges WHERE user_id = %s AND range_start = %s AND range_end = %s
                    """, (user_id, start, end))
                    if not cursor.fetchone():
                        cursor.execute("""
                            INSERT INTO scanned_ranges (user_id, range_start, range_end, scan_time, gpu_count, gpu_info)
                            VALUES (%s, %s, %s, NOW(), %s, %s)
                        """, (user_id, start, end, gpu_count, gpu_info))
                        print(f"[RANGE]  Inserted: {start} : {end} | GPUs: {gpu_count} | Info: {gpu_info.splitlines()[0] if gpu_info else 'N/A'}")
                except Exception as e:
                    print(f"[ERROR] Range insert failed: {e}")

            connection.commit()
            open(RANGE_LOG_FILE, "w", encoding="utf-8").close()

        except Exception as e:
            print(f"[ERROR] Scanned range loop: {e}")
        finally:
            try:
                if connection:
                    connection.close()
            except:
                pass
            time.sleep(random.randint(40, 120))  # ⏱️ randomized delay

# 🔁 Start thread for scanned ranges
threading.Thread(target=send_scanned_ranges_loop, daemon=True).start()
